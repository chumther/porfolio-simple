$(document).ready(function() {
    $('body').addClass('fade-in');
});